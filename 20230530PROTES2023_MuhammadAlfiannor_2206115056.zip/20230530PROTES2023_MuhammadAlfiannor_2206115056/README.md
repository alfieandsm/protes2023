Folder 20230530PROTES2023_Muhammadalfiannor.zip ini berisi beberapa file:

#####################################################################
#           Nama file:        #              Deskripsi              #
#####################################################################
# 1._bookdown.yml             # syntax untuk menggabungkan          #
#  	                          # file Rmd yang ada di folder   		  #
#    	                        # tanggapan ini.                      #
#                             #                                     #
#                             #                                     #
# 2. _output.yml              # syntax untuk mengatur output        # 
#                             # file Rmd yang ada dalam folder      #
#                             # tanggapan ini menjadi pdf.          #
#                             #                                     #
#                             #                                     #
# 3. README.md                # Keterangan isi folder .zip   #
#                             #                                     #
#                             #                                     #
# 4.  01-informasi_umum.Rmd   # Data diri penulis proposal tesis    #
#                             #                                     #
#                             #                                     #
# 5.  2a-pendahuluan.Rmd      # Pendahuluan                         #
#                             #                                     #
#                             #                                     #
# 6. 2b-metode.Rmd            # Metode penelitian                   #
#                             #                                     #
#                             #                                     #
# 7. 2c-manfaat.Rmd           # Manfaat penelitian                  #
#                             #                                     #
#                             #                                     #
# 8. 2d-referensi.Rmd         # Referensi                           #
#                             #                                     #
#                             #                                     #
# 9. 3-lampiran.Rmd           # Tabel literatur review              # 
#                             #                                     #
#                             #                                     #
# 10. gambar                  # Folder berisi gambar                # 
#                             #                                     #
#                             #                                     #
# 5. index.Rmd                # syntax untuk mengatur format        # 
#                             # isi dari file Rmd yang ada dalam    #
#                             # folder tanggapan.                   #
#                             #                                     #
#                             #                                     #
# 6. preamble.tex             # daftar packages yang digunakan      #
#                             #  dalam bookdown dan format untuk    #
#                             # build book, termasuk package untuk  # 
#                             # jenis tulisan dan spasi antar huruf #
#                             # dan kata.                           #
#####################################################################
